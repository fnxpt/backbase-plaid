# Backbase Project 

This project is created by http://start.backbase.com 

## README files

- [Backbase 6 :: Platform - Identity](platform/README.md)
- [CX 6.1 series with identity](cx6-targeting/README.md)
- [Backbase 6 :: DBS](dbs/README.md)
- [Identity](identity/README.md)
- [Backbase 6 :: Statics](statics/README.md)
