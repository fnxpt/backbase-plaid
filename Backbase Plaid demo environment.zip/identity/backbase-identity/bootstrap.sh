#! /bin/bash

if [ -z "$QUARKUS_LOG_LEVEL" ]; then
 export QUARKUS_LOG_LEVEL='INFO';
fi

echo "Logging Level : $QUARKUS_LOG_LEVEL"
exec java -cp "mysql-connector-java.jar:backbase-identity.jar:themes/*:providers/*" \
-Dkeycloak.migration.action=import \
-Dkeycloak.migration.strategy=IGNORE_EXISTING \
-Dkeycloak.profile.feature.upload_scripts=enabled \
-Djboss.server.config.dir=/tmp/keycloak-export \
io.quarkus.runner.GeneratedMain
